Service Type Price
Item Total Price
Extra Price
Discount
Payment in Cash
Paymeny in UPI/Online
Total Paid
Balance Payment
Payment Due Date